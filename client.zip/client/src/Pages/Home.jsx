import React, { useState, useEffect } from 'react'
import { Button } from '@chakra-ui/react'
import LoginLogoutPage from '@/components/components/login';

const Home = () => {
  return (<LoginLogoutPage />);
}

export default Home