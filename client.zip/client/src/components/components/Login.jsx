import React, { useEffect, useState } from 'react';
import { Button } from '@chakra-ui/react';
import useRegisterWithUser from '@/hooks/useRegisterWithUser';
import useSignInWithUser from '@/hooks/useLoginWithUsername';
import { Box, Text, Stack, AbsoluteCenter, Image } from '@chakra-ui/react';
import HomePage from './Home/Home';

const LoginLogoutPage = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLogin, setIsLogin] = useState(true);
  const [isRegister, setIsRegister] = useState(false);
  const [isAuthed, setIsAuthed] = useState(false);
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });
  const { register, loading, error } = useRegisterWithUser(); // Destructure from the hook
  const { loginUser, loadingUser, errorUser } = useSignInWithUser(); // Destructure from the hook

  const handleChange = (e) => {
    setFormData(prevState => ({
      ...prevState,
      [e.target.name]: e.target.value
    }));
  };
  useEffect(() => {
    fetch("/api/authed").then(
      res => res.json()
    ).then(data => {
        console.log(data);
      data.Authed ? setIsAuthed(true) : window.location.href = "http://127.0.0.1:5200/api";
    })  
  }, []);


  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (isRegister) {
        const user = await register(formData.email, formData.password);
        console.log(user); // Optionally handle the user data after registration
        setIsLoggedIn(true);
      } else {
        const user = await loginUser(formData.email, formData.password);
        console.log(user); // Optionally handle the user data after login
        setIsLoggedIn(true);
      }
      window.location.href = "http://127.0.0.1:5200/api";
    } catch (error) {
      console.error("Error during registration:", error);
    }
  };

  const login = () => {
    setIsLogin(true);
    setIsRegister(false);
  };

  useEffect(() => {
    const user = localStorage.getItem("user");
    if (user) {
      setIsLoggedIn(true);
    }
  }, []);

  const registerPage = () => {
    setIsRegister(true);
    setIsLogin(false);
  };

  const loginComp = (
    <div>
      <form onSubmit={handleSubmit}>
        <Stack>
        <input
          type="email"
          placeholder="email"
          value={formData.email}
          onChange={handleChange}
          name="email"
        />
        <input
          type="password"
          placeholder="password"
          value={formData.password}
          onChange={handleChange}
          name="password"
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Logging in...' : 'Login'}
        </button>
        </Stack>
      </form>
    </div>
  );

  const registerComp = (
    <div>
      <form onSubmit={handleSubmit}>
        <Stack>
        <input
          type="email"
          placeholder="email"
          value={formData.email}
          onChange={handleChange}
          name="email"
        />
        <input
          type="password"
          placeholder="password"
          value={formData.password}
          onChange={handleChange}
          name="password"
        />
        <button type="submit" disabled={loading}>
          {loading ? 'Registering...' : 'Register'}
        </button>
        </Stack>
      </form>
      {error && <p className="text-red-500">{error}</p>} {/* Display error message */}
    </div>
  );

  return isLoggedIn ? (
    
    <HomePage />
  ) : (
    <AbsoluteCenter>
        <Stack>
        <Image 
                src='../../logo.jpg'
                boxSize="200px"
                borderRadius="full"
                fit='fill'
                alt=""
                ml={'auto'}
                mr={'auto'}
                mb={25}
                />
        <Box  maxW="sm" borderWidth="1px" bg={'gray.100'}>
            <Stack>
          <h1 className="text-xl font-bold mb-4 text-center">
            Please <button onClick={login}>login</button> or <button onClick={registerPage}>register</button>
          </h1>
          {isLogin ? loginComp : registerComp}
          </Stack>
        </Box>
        </Stack>
        </AbsoluteCenter>

  );
};

export default LoginLogoutPage;