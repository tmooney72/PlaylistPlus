// import React from "react";

// const HomePage = () => {
//   return (
//     <div style={{ minHeight: '100vh', backgroundColor: '#f3f4f6', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center' }}>
//       <header style={{ width: '100%', backgroundColor: '#fff', boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1)', padding: '1rem', textAlign: 'center' }}>
//         <h1 style={{ fontSize: '1.5rem', fontWeight: 'bold', color: '#1f2937' }}>Welcome to PlaylistPlus</h1>
//       </header>
//       <main style={{ flex: 1, width: '100%', maxWidth: '800px', padding: '2rem', boxSizing: 'border-box' }}>
//         <section style={{ display: 'grid', gridTemplateColumns: '1fr', gap: '1rem' }}>
//           <div style={{ borderRadius: '1rem', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)', padding: '1rem', backgroundColor: '#fff' }}>
//             <h2 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1f2937', marginBottom: '0.5rem' }}>Feature 1</h2>
//             <p style={{ color: '#4b5563' }}>Learn more about this amazing feature that improves your experience.</p>
//             <button style={{ marginTop: '1rem', padding: '0.5rem 1rem', backgroundColor: '#3b82f6', color: '#fff', border: 'none', borderRadius: '0.375rem', cursor: 'pointer' }}>Learn More</button>
//           </div>
//           <div style={{ borderRadius: '1rem', boxShadow: '0 2px 4px rgba(0, 0, 0, 0.1)', padding: '1rem', backgroundColor: '#fff' }}>
//             <h2 style={{ fontSize: '1.25rem', fontWeight: '600', color: '#1f2937', marginBottom: '0.5rem' }}>Feature 2</h2>
//             <p style={{ color: '#4b5563' }}>Discover how this feature can make your life easier.</p>
//             <button style={{ marginTop: '1rem', padding: '0.5rem 1rem', backgroundColor: '#3b82f6', color: '#fff', border: 'none', borderRadius: '0.375rem', cursor: 'pointer' }}>Learn More</button>
//           </div>
//         </section>
//       </main>
//       <footer style={{ width: '100%', backgroundColor: '#fff', boxShadow: '0 -1px 3px rgba(0, 0, 0, 0.1)', padding: '1rem', marginTop: '1rem', textAlign: 'center' }}>
//         <p style={{ color: '#4b5563' }}>© 2025 Your Website. All rights reserved.</p>
//       </footer>
//     </div>
//   );
// };
import React, { useState, useEffect } from 'react';
import { 
  Button, 
  Text, 
  HStack, 
  Center, 
  Image, 
  VStack, 
  SimpleGrid 
} from '@chakra-ui/react';
import { Link } from 'react-router-dom'; // Assuming you're using React Router

const HomePage = () => {
  const [recentlyPlayed, setRecentlyPlayed] = useState([]);
  const [recommendations, setRecommendations] = useState([]);
  const [loading, setLoading] = useState(true);

  // Mock data - replace with your actual API calls
  useEffect(() => {
    // Simulate API call
    setTimeout(() => {
      setRecentlyPlayed([
        { id: 1, name: "Summer Hits", image: "https://via.placeholder.com/150", songs: 24 },
        { id: 2, name: "Workout Mix", image: "https://via.placeholder.com/150", songs: 18 },
        { id: 3, name: "Chill Vibes", image: "https://via.placeholder.com/150", songs: 32 },
      ]);
      
      setRecommendations([
        { id: 4, name: "Hip Hop Classics", image: "https://via.placeholder.com/150", songs: 45 },
        { id: 5, name: "90s Rock", image: "https://via.placeholder.com/150", songs: 38 },
        { id: 6, name: "Indie Discoveries", image: "https://via.placeholder.com/150", songs: 27 },
        { id: 7, name: "Electronic Dance", image: "https://via.placeholder.com/150", songs: 41 },
      ]);
      
      setLoading(false);
    }, 1000);
  }, []);

  const PlaylistCard = ({ playlist }) => (
    <VStack 
      p={4}
      bg="white" 
      borderRadius="md"
      boxShadow="sm"
      _hover={{ boxShadow: "md", transform: "translateY(-2px)" }}
      transition="all 0.2s"
      spacing={3}
      align="center"
      cursor="pointer"
    >
      <Image 
        src={playlist.image} 
        alt={`${playlist.name} cover`}
        borderRadius="md"
        boxSize="150px"
        objectFit="cover"
      />
      <VStack spacing={1} align="center">
        <Text 
          fontWeight="bold" 
          fontSize="lg" 
          textAlign="center"
          noOfLines={1}
        >
          {playlist.name}
        </Text>
        <Text 
          fontSize="sm" 
          color="gray.500"
        >
          {playlist.songs} songs
        </Text>
      </VStack>
    </VStack>
  );

  const Section = ({ title, children }) => (
    <VStack align="stretch" spacing={4} mb={8}>
      <Text fontSize="xl" fontWeight="bold" color="purple.600" px={4}>
        {title}
      </Text>
      {children}
    </VStack>
  );

  return (
    <>
      {/* Hero Section */}
      <VStack 
        spacing={6} 
        bg="purple.500" 
        color="white" 
        py={16} 
        px={4} 
        mb={8}
        borderRadius="md"
        mx={4}
      >
        <Text fontSize="4xl" fontWeight="bold" textAlign="center">
          Welcome to Your Music Hub
        </Text>
        <Text fontSize="xl" textAlign="center" opacity={0.9}>
          Discover, organize, and enjoy your favorite tunes
        </Text>
        <HStack spacing={4} pt={4}>
          <Button 
            as={Link} 
            to="/playlists" 
            colorScheme="whiteAlpha" 
            size="lg"
          >
            Browse Playlists
          </Button>
          <Button 
            as={Link} 
            to="/search" 
            colorScheme="blackAlpha" 
            size="lg"
          >
            Search Music
          </Button>
        </HStack>
      </VStack>

      {/* Content Sections */}
      {loading ? (
        <Center h="200px">
          <Text>Loading your music...</Text>
        </Center>
      ) : (
        <>
          <Section title="Recently Played">
            <SimpleGrid columns={[1, 2, 3]} spacing={6} px={4}>
              {recentlyPlayed.map(playlist => (
                <PlaylistCard key={playlist.id} playlist={playlist} />
              ))}
            </SimpleGrid>
          </Section>

          <Section title="Recommended For You">
            <SimpleGrid columns={[1, 2, 4]} spacing={6} px={4}>
              {recommendations.map(playlist => (
                <PlaylistCard key={playlist.id} playlist={playlist} />
              ))}
            </SimpleGrid>
          </Section>

          <Section title="Quick Access">
            <HStack spacing={4} overflowX="auto" px={4} pb={2}>
              <Button colorScheme="purple" variant="outline">Top Charts</Button>
              <Button colorScheme="purple" variant="outline">New Releases</Button>
              <Button colorScheme="purple" variant="outline">Your Favorites</Button>
              <Button colorScheme="purple" variant="outline">Recently Added</Button>
              <Button colorScheme="purple" variant="outline">Made For You</Button>
            </HStack>
          </Section>
        </>
      )}

      {/* Feature Highlight */}
      <VStack 
        align="stretch" 
        bg="gray.50" 
        p={6} 
        borderRadius="md" 
        mx={4} 
        mb={8}
      >
        <Text fontSize="lg" fontWeight="bold" mb={2}>
          Automatic Playlist Creation
        </Text>
        <Text color="gray.600" mb={4}>
          Let our AI analyze your listening habits and create personalized playlists just for you.
        </Text>
        <Button colorScheme="purple" alignSelf="flex-start">
          Try It Now
        </Button>
      </VStack>
    </>
  );
};

export default HomePage;
